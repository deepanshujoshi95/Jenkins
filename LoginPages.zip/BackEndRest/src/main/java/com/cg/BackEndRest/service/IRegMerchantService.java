package com.cg.BackEndRest.service;

import java.util.List;


import com.cg.BackEndRest.model.Merchant;

public interface IRegMerchantService {

	public void saveMerchant(Merchant merchant);
	public List<Merchant> getAllMerchants();
	public Merchant getValidMerchant(String username, String password);
}
