package com.cg.BackEndRest.service;

import com.cg.BackEndRest.model.Admin;

public interface IAdminLogin {

	public Admin getAdmin(String username, String password);
}
