package com.cg.BackEndRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndRestApplication.class, args);
	}
}
